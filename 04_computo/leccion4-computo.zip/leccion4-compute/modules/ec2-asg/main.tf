# ═══════════════════════════════════════════════════════════════════
#  SERVICIO 1 — EC2 con Auto Scaling Group
#  Free Tier: t2.micro, hasta 750 horas/mes gratis
# ═══════════════════════════════════════════════════════════════════

# ── Security Group: ALB público ───────────────────────────────────
resource "aws_security_group" "alb" {
  name        = "${var.project_name}-ec2-alb-sg"
  description = "ALB EC2: permite HTTP desde Internet"
  vpc_id      = var.vpc_id

  ingress {
    from_port   = 80
    to_port     = 80
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
    description = "HTTP público"
  }

  egress {
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }
}

# ── Security Group: Instancias EC2 ────────────────────────────────
resource "aws_security_group" "ec2" {
  name        = "${var.project_name}-ec2-instance-sg"
  description = "EC2: solo tráfico desde el ALB"
  vpc_id      = var.vpc_id

  ingress {
    from_port       = 80
    to_port         = 80
    protocol        = "tcp"
    security_groups = [aws_security_group.alb.id]
    description     = "HTTP desde ALB"
  }

  egress {
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }
}

# ── ALB ───────────────────────────────────────────────────────────
resource "aws_lb" "ec2" {
  name               = "${var.project_name}-ec2-alb"
  internal           = false
  load_balancer_type = "application"
  security_groups    = [aws_security_group.alb.id]
  subnets            = var.subnet_ids
}

resource "aws_lb_target_group" "ec2" {
  name     = "${var.project_name}-ec2-tg"
  port     = 80
  protocol = "HTTP"
  vpc_id   = var.vpc_id

  health_check {
    path                = "/"
    healthy_threshold   = 2
    unhealthy_threshold = 3
    interval            = 15
  }
}

resource "aws_lb_listener" "ec2" {
  load_balancer_arn = aws_lb.ec2.arn
  port              = 80
  protocol          = "HTTP"

  default_action {
    type             = "forward"
    target_group_arn = aws_lb_target_group.ec2.arn
  }
}

# ── Launch Template ───────────────────────────────────────────────
resource "aws_launch_template" "app" {
  name_prefix   = "${var.project_name}-ec2-lt-"
  image_id      = var.ami_id
  instance_type = var.instance_type

  # User data: instala y arranca nginx con una página de demo
  user_data = base64encode(<<-EOF
    #!/bin/bash
    dnf install -y nginx
    systemctl enable nginx
    systemctl start nginx

    # Página de demostración con hostname de la instancia
    INSTANCE_ID=$(curl -s http://169.254.169.254/latest/meta-data/instance-id)
    AZ=$(curl -s http://169.254.169.254/latest/meta-data/placement/availability-zone)
    cat > /usr/share/nginx/html/index.html <<HTML
    <!DOCTYPE html>
    <html>
    <head><title>Lección 4 – EC2 Auto Scaling</title></head>
    <body style="font-family:sans-serif;max-width:600px;margin:2rem auto">
      <h1>🖥️ Servicio 1: EC2</h1>
      <p><strong>Instance ID:</strong> $INSTANCE_ID</p>
      <p><strong>AZ:</strong> $AZ</p>
      <p><strong>Hora:</strong> $(date)</p>
      <p style="color:green">Auto Scaling activo ✓</p>
    </body>
    </html>
    HTML
  EOF
  )

  network_interfaces {
    associate_public_ip_address = true
    security_groups             = [aws_security_group.ec2.id]
  }

  tag_specifications {
    resource_type = "instance"
    tags = {
      Name = "${var.project_name}-ec2-app"
    }
  }
}

# ── Auto Scaling Group ────────────────────────────────────────────
resource "aws_autoscaling_group" "app" {
  name                = "${var.project_name}-ec2-asg"
  min_size            = var.min_size
  max_size            = var.max_size
  desired_capacity    = var.desired_capacity
  vpc_zone_identifier = var.subnet_ids
  target_group_arns   = [aws_lb_target_group.ec2.arn]
  health_check_type   = "ELB"

  launch_template {
    id      = aws_launch_template.app.id
    version = "$Latest"
  }

  tag {
    key                 = "Name"
    value               = "${var.project_name}-ec2-asg"
    propagate_at_launch = true
  }
}

# ── Política de escalado: CPU > 60% → añade instancias ───────────
resource "aws_autoscaling_policy" "scale_out" {
  name                   = "${var.project_name}-scale-out"
  autoscaling_group_name = aws_autoscaling_group.app.name
  policy_type            = "TargetTrackingScaling"

  target_tracking_configuration {
    predefined_metric_specification {
      predefined_metric_type = "ASGAverageCPUUtilization"
    }
    # Escala cuando la CPU promedio supera el 60%
    target_value = 60.0
  }
}

# ── Alarma CloudWatch para la métrica de escalado ────────────────
resource "aws_cloudwatch_metric_alarm" "high_cpu" {
  alarm_name          = "${var.project_name}-ec2-high-cpu"
  comparison_operator = "GreaterThanThreshold"
  evaluation_periods  = 2
  metric_name         = "CPUUtilization"
  namespace           = "AWS/EC2"
  period              = 60
  statistic           = "Average"
  threshold           = 60
  alarm_description   = "CPU > 60% durante 2 minutos → Auto Scaling actúa"

  dimensions = {
    AutoScalingGroupName = aws_autoscaling_group.app.name
  }
}
