output "alb_dns_name"    { value = aws_lb.ec2.dns_name }
output "asg_name"        { value = aws_autoscaling_group.app.name }
output "launch_template" { value = aws_launch_template.app.id }
