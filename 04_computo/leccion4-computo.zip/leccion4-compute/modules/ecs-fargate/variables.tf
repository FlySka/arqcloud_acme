variable "project_name"     { type = string }
variable "environment"      { type = string }
variable "vpc_id"           { type = string }
variable "subnet_ids"       { type = list(string) }
variable "container_image"  { type = string }
variable "container_cpu"    { type = number }
variable "container_memory" { type = number }
variable "desired_count"    { type = number }
