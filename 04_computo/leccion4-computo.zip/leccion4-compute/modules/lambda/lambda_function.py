import json
import os
import time
import math

def handler(event, context):
    """
    Función Lambda de demostración — Lección 4.
    Responde con información del entorno de ejecución
    y ejecuta un pequeño cálculo para generar carga medible.
    """

    # Carga controlada: cálculo de números primos hasta N
    n = int(event.get("queryStringParameters", {}).get("n", "500") or "500")
    n = min(n, 5000)  # Límite de seguridad

    start = time.time()
    primes = _sieve(n)
    elapsed_ms = round((time.time() - start) * 1000, 2)

    body = {
        "servicio": "Lambda",
        "leccion": 4,
        "funcion": context.function_name,
        "version": context.function_version,
        "memoria_mb": context.memory_limit_in_mb,
        "request_id": context.aws_request_id,
        "entorno": os.environ.get("ENVIRONMENT", "dev"),
        "calculo": {
            "descripcion": f"Números primos hasta {n}",
            "resultado_count": len(primes),
            "mayor_primo": primes[-1] if primes else None,
            "tiempo_ms": elapsed_ms,
        },
        "escalabilidad": (
            "Lambda escala automáticamente a miles de ejecuciones "
            "concurrentes sin configuración adicional."
        ),
    }

    return {
        "statusCode": 200,
        "headers": {
            "Content-Type": "application/json",
            "X-Leccion": "4",
            "X-Servicio": "Lambda",
        },
        "body": json.dumps(body, indent=2, ensure_ascii=False),
    }


def _sieve(limit: int) -> list[int]:
    """Criba de Eratóstenes — genera carga de CPU medible."""
    if limit < 2:
        return []
    is_prime = [True] * (limit + 1)
    is_prime[0] = is_prime[1] = False
    for i in range(2, int(math.sqrt(limit)) + 1):
        if is_prime[i]:
            for j in range(i * i, limit + 1, i):
                is_prime[j] = False
    return [i for i, p in enumerate(is_prime) if p]
