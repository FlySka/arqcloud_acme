output "function_name" { value = aws_lambda_function.demo.function_name }
output "function_arn"  { value = aws_lambda_function.demo.arn }
output "api_url"       { value = "${aws_apigatewayv2_stage.lambda.invoke_url}/demo" }
