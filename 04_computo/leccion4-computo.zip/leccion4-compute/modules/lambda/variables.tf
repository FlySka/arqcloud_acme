variable "project_name" { type = string }
variable "environment"  { type = string }
variable "memory_size"  { type = number }
variable "timeout"      { type = number }
